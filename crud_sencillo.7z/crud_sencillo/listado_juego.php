<?php
//incluir conexion bd
$bd = include("bd.php");

//sentecia para traer los resultados
$sentencia = $bd->query("SELECT * FROM juegos");

//convertir los resultados en un array
$registros = $sentencia->fetch_all(MYSQLI_ASSOC);

?>
<?php include("header.php"); ?>
<div class="row">
  <div class="col-12">
    <h1 class="text-center">listado de juegos </h1>
  </div>
  <div class="offset-9 col-3">
    <a href="formulario.php" class="btn btn-primary">Crear juego</a>
  </div>
  <div class="col-12">
    <table class="table">
      <thead>
        <tr>
          <th scope="col">Id</th>
          <th scope="col">nombre</th>
          <th scope="col">sipnosis</th>
          <th scope="col">imagen</th>
          <th scope="col">editar</th>
          <th scope="col">eliminar</th>
        </tr>
      </thead>
      <tbody>
     
        <?php foreach ($registros as $registro) { ?>
          <tr>
            <th> <?php echo $registro["id"]; ?> </th>
            <td> <?php echo $registro["nombre"]; ?> </td>
            <td> <?php echo $registro["descripcion"]; ?> </td>
            <td> <img src="<?php echo $registro["imagen"]; ?> " width="15%"> </td>
            <td><a href="editar.php?id=<?php echo $registro["id"]; ?>   " class="btn btn-warning">editar </a> </td>
            <td><a href="eliminar.php?id=<?php echo $registro["id"]; ?>   " class="btn btn-danger">eliminar </a></td>
          </tr>
  </div>
</div>

<?php } ?>
</tbody>
</table>
<?php include("footer.php"); ?>