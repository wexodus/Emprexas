<?php 
    //recibo id del listado
    $id=$_GET['id'];
    echo $id;
    //me conecto a la bd
    $bd =include("bd.php");
    //sentencia sql
    $sentencia=$bd->prepare("SELECT * FROM juegos WHERE id=?");
    $sentencia ->bind_param("i",$id);
    $sentencia->execute();
    //resultado de la consulta
    $resul=$sentencia->get_result();
    //pasar resultados a un array
    $juego=$resul->fetch_assoc();
    //comprobar que tenemos el juego de la consulta
    if(!$juego){
        echo "no hay un juego con ese ID";
    }


?>
<?php include("header.php");?>

<div class="col-sm-6 offset-sm-3">
  <h1 class="text-center">editar Video Juegos</h1>

  <form action="actualizar.php" method="post">
    <div class="form-group">
      <label for="exampleFormControlInput1">nombre del juego</label>
      <input name="nombre" value="<?php echo $juego['nombre'];  ?>" type="text" class="form-control" id="exampleFormControlInput1" placeholder="ejemplo mario">
      <input type="hidden" name="id" value="<?php echo $juego['id'];?>">
    </div>
    <div class="form-group">
      <label for="exampleFormControlTextarea1">sinopsis del juego</label>
      <input name="descripcion" value="<?php echo $juego['descripcion'];  ?>" class="form-control" id="exampleFormControlTextarea1"></input>
    </div>

    <div class="form-group">
      <label for="exampleFormControlTextarea1">imagen del juego</label>
      <input name="imagen" type="file" class="form-control">
    </div>

    <div class="form-group text-center">
      <button type="submit" class="btn btn-success">Guardar juego</button>
    </div>
  </form>
</div>

<?php include("footer.php");?>