<?php
//icluir conexion bd
$bd =include("bd.php");

if(isset($_FILES['imagen'])){
  
//variable del formulario 
$nombre=$_POST['nombre'];
$des=$_POST['descripcion'];
$img=$_FILES['imagen']['name'];

//ruta imagen
$ruta= "http://localhost/CRUD_SENCILLO/imagenes/$img";
 
$directorio =$_SERVER['DOCUMENT_ROOT']."/CRUD_SENCILLO/imagenes/";
$subir_img_proyecto=$directorio.basename($_FILES['imagen']['name']);
if(move_uploaded_file($_FILES['imagen']['tmp_name'],$subir_img_proyecto)){

    $sentencia=$bd->prepare("INSERT INTO juegos(nombre,descripcion,imagen)
    values(?, ?, ?)");
    $sentencia->bind_param("sss",$nombre,$des,$ruta);
    
    //comprobar si se registraron los datos
    if($sentencia->execute()){
        echo " <script>  alert ('se registraron los datos') </script>";
    
    }else{
        echo" <script>   ('no se registraron los datos') </script>  ";
    }
    
    header("location:formulario.php");

}else{
    echo"no se pudo guardar la imagen en el directorio";
}

//sentencia sql

}else{
    echo"no se envio";
}















