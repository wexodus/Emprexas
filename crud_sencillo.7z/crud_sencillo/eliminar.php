<?php
//conectar bd
$bd =include("bd.php");
//recibir id
$id=$_GET["id"];
echo"<p> este es el id: ".$id."<p>";
//sentencia para eliminar el registro
$sentencia =$bd->prepare("DELETE FROM juegos  WHERE id = ?");

//pasar el id a la funcion param 
$sentencia->bind_param("i",$id);
//ejecutar sentencia para eliminar 
$sentencia->execute();

header("location: listado_juego.php");