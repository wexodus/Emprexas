<?php
//variable de conexion
$host = "localhost";
$user = "root";
$bd = "videojuego";
$contraseña = "";

//conexion bd
$conexion = new mysqli($host,$user,$contraseña,$bd);

//comprobar conexion 
if($conexion->connect_error){
    echo"no se pudo conectar a la bd". $conexion->connect_error;
}else{
    echo"";
}
//retornar el objeto conexion
return $conexion;