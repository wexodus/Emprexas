<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $servername = "localhost";
    $database = "nose";
    $username = "root";
    $password = "";

    $conn=mysqli_connect($servername, $username, $password, $database);
    if (!$conn) {
        die("Connected failed: ".mysqli_connect_error());
    }
    echo "Connected Succesfully";
    mysqli_close($conn);
    ?>
</body>
</html>